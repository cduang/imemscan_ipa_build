# iMemScan Trollstore 简体中文版

这个版本的 iMemScan 已经本地化为简体中文版本

## 安装方法

1. 下载 **iMemscan.tipa** 并通过 Trollstore 安装

## 捐赠

支持作者: https://www.paypal.me/zSaaiq
