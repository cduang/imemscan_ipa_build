//
//  Root.h
//  Root
//
//  Created by yiming on 2021/8/14.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Root : NSObject

@end

NS_ASSUME_NONNULL_END
